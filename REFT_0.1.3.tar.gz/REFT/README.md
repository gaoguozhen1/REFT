# REFT

REFT (Root Exudate Feature Toolkit) is an R package for molecule-oriented analysis of root exudate and metabolomics annotation tables. It supports batch database searching, SMILES matching, and calculation of six molecular descriptors.

## Main features

- Read Excel annotation tables
- Match PubChem records in the order `Name -> Other_name(Kegg_name) -> Kegg_ID -> HMDB_ID`
- Export a matching log and unmatched records
- Calculate six molecular descriptors using `rcdk`:
  - MW
  - nHBAcc
  - ALogP
  - FMF
  - HybRatio
  - nAcid
- Run the complete workflow with one function

## Install dependencies

```r
install.packages(c(
  "readxl", "dplyr", "purrr", "stringr", "tibble",
  "writexl", "webchem", "rcdk", "rcdklibs"
))
```

## Install REFT

### Option 1: Install from a source directory

```r
install.packages("REFT", repos = NULL, type = "source")
```

### Option 2: Install from a source tarball

```r
install.packages("REFT_0.1.3_no_chinese_source.tar.gz", repos = NULL, type = "source")
```

## Quick start

```r
library(REFT)

reft_run_simple(
  input_file = "example_root_exudate.xlsx"
)
```

## Custom column names

```r
library(REFT)

res <- reft_run(
  input_file = "your_data.xlsx",
  name_col = "Name",
  other_col = "Other_name(Kegg_name)",
  hmdb_col = "HMDB_ID",
  kegg_col = "Kegg_ID",
  output_dir = "results"
)
```

## Output files

By default, the following files are generated in `output_dir`:

- `metabolites_6_descriptors.xlsx`
- `unmatched_smiles.xlsx`
- `pubchem_match_log.xlsx`

## Returned object

Both `reft_run()` and `reft_run_simple()` return a named list:

- `descriptors`: final result table containing SMILES and six descriptors
- `unmatched`: records that were not matched to SMILES
- `match_log`: PubChem matching log

## Notes

- KEGG_ID and HMDB_ID currently follow the original workflow and are queried through PubChem name-based searching, so the hit rate may vary among identifiers.
- `rcdk` requires a working Java environment.
- If PubChem network access is unstable, some records may return `NA`.

## Java / rcdk note

REFT can be installed without loading `rcdk` at package startup. Only the molecular descriptor calculation step requires `rcdk`/`rJava`.

If descriptor calculation fails on Windows, check that Java is installed and that R and Java use matching architectures.
