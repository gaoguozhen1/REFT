library(REFT)

res <- reft_run(
  input_file = "your_data.xlsx",
  name_col = "Name",
  other_col = "Other_name(Kegg_name)",
  hmdb_col = "HMDB_ID",
  kegg_col = "Kegg_ID",
  output_dir = "results",
  verbose = TRUE
)

head(res$descriptors)
