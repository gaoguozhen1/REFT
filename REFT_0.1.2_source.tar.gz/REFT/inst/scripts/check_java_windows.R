cat("R architecture:", R.version$arch, "\n")
cat("java.home option:", getOption("java.home"), "\n")

if (requireNamespace("rJava", quietly = TRUE)) {
  cat("rJava is installed.\n")
  tryCatch({
    rJava::.jinit()
    cat("Java initialized successfully.\n")
  }, error = function(e) {
    cat("Java initialization failed:", conditionMessage(e), "\n")
  })
} else {
  cat("rJava is not installed.\n")
}
