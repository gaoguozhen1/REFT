library(REFT)

res <- reft_run_simple(
  input_file = "高国震meta_intensity_neg_hmdb_kegg_lipidmaps(1).xlsx",
  output_dir = "results",
  verbose = TRUE
)

head(res$descriptors)
