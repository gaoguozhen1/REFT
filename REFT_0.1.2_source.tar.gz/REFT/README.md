# REFT

REFT (Root Exudate Feature Toolkit) 是一个面向根系分泌物/代谢组注释表的 R 包，用于批量搜库、SMILES 匹配和 6 个分子描述符计算。

## 主要特点

- 读取 Excel 注释表
- 按 `Name -> Other_name(Kegg_name) -> Kegg_ID -> HMDB_ID` 的顺序匹配 PubChem
- 输出匹配日志和未匹配条目
- 使用 `rcdk` 计算 6 个分子描述符：
  - MW
  - nHBAcc
  - ALogP
  - FMF
  - HybRatio
  - nAcid
- 一行代码完成整个流程

## 依赖安装

```r
install.packages(c(
  "readxl", "dplyr", "purrr", "stringr", "tibble",
  "writexl", "webchem", "rcdk", "rcdklibs"
))
```

## 安装 REFT

### 方式 1：从源码目录安装

```r
install.packages("REFT", repos = NULL, type = "source")
```

### 方式 2：从压缩包安装

```r
install.packages("REFT_0.1.1_source.tar.gz", repos = NULL, type = "source")
```

## 最简单用法

```r
library(REFT)

reft_run_simple(
  input_file = "高国震meta_intensity_neg_hmdb_kegg_lipidmaps(1).xlsx"
)
```

## 自定义列名

```r
library(REFT)

res <- reft_run(
  input_file = "your_data.xlsx",
  name_col = "Name",
  other_col = "Other_name(Kegg_name)",
  hmdb_col = "HMDB_ID",
  kegg_col = "Kegg_ID",
  output_dir = "results"
)
```

## 输出文件

默认会在 `output_dir` 中生成：

- `metabolites_6_descriptors.xlsx`
- `unmatched_smiles.xlsx`
- `pubchem_match_log.xlsx`

## 返回值

`reft_run()` 和 `reft_run_simple()` 都返回一个列表：

- `descriptors`：最终结果表
- `unmatched`：未匹配到 SMILES 的条目
- `match_log`：PubChem 匹配日志

## 注意事项

- 当前 KEGG_ID 与 HMDB_ID 仍沿用原始脚本逻辑，通过 PubChem 名称检索尝试匹配，因此对部分 ID 的命中率可能有限。
- `rcdk` 运行依赖 Java 环境。
- PubChem 网络访问不稳定时，部分条目可能会返回 NA。


## Java / rcdk note

REFT can be installed without loading `rcdk` at package startup.
Only the molecular descriptor calculation step needs `rcdk`/`rJava`.

If descriptor calculation fails on Windows, check that Java is installed and that
R and Java use matching architectures.
